import org.junit.Test;

import static org.junit.Assert.*;

public class TribonacciTest {

    @Test
    public void tribonacciTest() {
        // test data 1
        // 想要增加难度的同学，可以使用这组数据
        // 思考怎样对你的函数进行改进，更快地得到结果。
//         long[] expected = new long[] {0,1,1,4,615693474,612979045863284359L};
//
//         int[] input = new int[] {0,1, 2, 4, 35, 69};

        // test data 2


        long[] expected = new long[] {0,1,1,4,615693474};
        int[] input = new int[] {0,1, 2, 4, 35};
        long start = System.currentTimeMillis();
        for (int i = 0 ; i < input.length; i++) {
            Tribonacci t = new Tribonacci();
            assertEquals(expected[i], t.tribonacci(input[i]));
        }
        long end = System.currentTimeMillis();
        System.out.println("Time cost: " + (end - start)/ 1000.0+" seconds." );
    }
}