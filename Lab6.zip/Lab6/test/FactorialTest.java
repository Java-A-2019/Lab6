import static org.junit.Assert.*;

public class FactorialTest {

    @org.junit.Test
    public void factorialTest() {
        int n = 15;
        int fac = 1;
        for (int i = n; i > 0; i--) {
            fac *= i;
        }
        assertEquals(fac, Factorial.factorial(n));
    }
}