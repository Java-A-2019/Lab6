public class Factorial {
    /**
     * compute factorial
     * @param n compute factorial of n
     * @return int return factorial of n
     * */
    public static int factorial(int n) {
        if (n <= 1) return 1;
        return n * factorial(n-1);
    }
}
