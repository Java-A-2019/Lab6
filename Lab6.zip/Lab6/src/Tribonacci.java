import java.math.BigInteger;

public class Tribonacci {
    public long tribonacci(int n) {
        return 0;
    }
}
