public class Tribonacci {
    public int tribonacci(int n) {
        // TODO: 2019/10/28 type in your code here. And then run the test in TribonacciTest
        return 0;
    }
}
